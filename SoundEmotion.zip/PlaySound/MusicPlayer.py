import os
import sys
import random
from PyQt5.QtWidgets import QApplication, QMainWindow, QFileDialog
from PyQt5.QtMultimedia import QMediaPlayer, QMediaContent
from PyQt5.QtCore import QUrl
from PyQt5.uic import loadUi

from PyQt5.QtGui import QMovie

class MusicPlayer(QMainWindow):
    def __init__(self):
        super().__init__()

        loadUi(r"C:\Users\dromu\Unimayor\Urbanphony\SoundEmotion\PlaySound\Reproductor.ui", self)

        self.setWindowTitle(r"Music Player")

        # Crear una instancia de QMovie y asociarla con el QLabel
        self.gif_movie = QMovie("Reproductor.gif")
        self.gif_label.setMovie(self.gif_movie)

        # Iniciar la reproducción del GIF
        self.gif_movie.start()

        self.player = QMediaPlayer()
        self.playlist = []
        self.current_track_index = -1

        self.Play.clicked.connect(self.play_music)
        # self.Select_Folder.clicked.connect(self.select_folder)
        # self.Stop.clicked.connect(self.stop_music)  # Conectar el botón Stop

    def select_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Select Music Folder")
        if folder:
            self.playlist = [os.path.join(folder, filename) for filename in os.listdir(folder) if filename.endswith(".mp3")]
            random.shuffle(self.playlist)
            self.current_track_index = -1

    def play_music(self):
        if not self.playlist:
            return

        self.current_track_index = (self.current_track_index + 1) % len(self.playlist)
        track = self.playlist[self.current_track_index]

        if self.player.state() == QMediaPlayer.PlayingState:
            self.player.stop()

        content = QMediaContent(QUrl.fromLocalFile(track))
        self.player.setMedia(content)
        self.player.play()

        # Actualizar el QLabel "Texto" con el nombre de la canción actual
        self.Texto.setText(os.path.basename(track))
        
    def stop_music(self):
        self.player.stop()  # Pausar la reproducción de la música


def run():
    window = MusicPlayer()
    window.showFullScreen()

if __name__ == "__main__":
    run()